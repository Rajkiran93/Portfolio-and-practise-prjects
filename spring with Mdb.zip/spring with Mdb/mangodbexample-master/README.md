HelloSpringWithMongoDB
======================

This is a demo web application web application built with Spring MVC 3.2 and Spring Data 1.2, integrating with the MongoDB document database.

This project would serve as a guide to new developers integrating Spring with MongoDB.


Check the related blog post at http://blog.manishchhabra.com/2013/04/spring-data-mongodb-example-with-spring-mvc-3-2/

Manish
